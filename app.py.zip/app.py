from flask import Flask,render_template,flash,redirect,request,send_from_directory,url_for, send_file
import mysql.connector, os
#Import libraries
import matplotlib.pyplot as plt
import wave
import pyaudio
from keras.models import load_model
import os
import glob
import librosa
import numpy as np
import pandas as pd
import librosa
import pyaudio
import wave
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import StandardScaler
from keras.models import load_model
import matplotlib.pyplot as plt

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    port="3306",
    database='music_rec'
)

mycursor = mydb.cursor()

def executionquery(query,values):
    mycursor.execute(query,values)
    mydb.commit()
    return

def retrivequery1(query,values):
    mycursor.execute(query,values)
    data = mycursor.fetchall()
    return data

def retrivequery2(query):
    mycursor.execute(query)
    data = mycursor.fetchall()
    return data


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/About')
def about():
    return render_template('about.html')

@app.route('/register', methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form['useremail']
        password = request.form['password']
        c_password = request.form['c_password']
        username = request.form['username']
        age = request.form['age']
        gender = request.form['gender']
        if password == c_password:
            query = "SELECT UPPER(email) FROM users"
            email_data = retrivequery2(query)
            email_data_list = []
            for i in email_data:
                email_data_list.append(i[0])
            if email.upper() not in email_data_list:
                query = "INSERT INTO users (email, password,username,age,gender) VALUES (%s, %s, %s, %s, %s)"
                values = (email, password,username,age, gender)
                executionquery(query, values)
                return render_template('login.html', message="Successfully Registered! Please go to login section")
            return render_template('register.html', message="This email ID is already exists!")
        return render_template('register.html', message="Conform password is not match!")
    return render_template('register.html')


@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form['useremail']
        password = request.form['password']
        
        query = "SELECT UPPER(email) FROM users"
        email_data = retrivequery2(query)
        email_data_list = []
        for i in email_data:
            email_data_list.append(i[0])

        if email.upper() in email_data_list:
            query = "SELECT UPPER(password) FROM users WHERE email = %s"
            values = (email,)
            password__data = retrivequery1(query, values)
            if password.upper() == password__data[0][0]:
                global user_email
                user_email = email

                return redirect("/home")
            return render_template('home.html', message= "Invalid Password!!")
        return render_template('login.html', message= "This email ID does not exist!")
    return render_template('login.html')


@app.route('/home')
def home():
    return render_template('home.html')

# Load SVD model and recommendation data
data = pd.read_csv('data_moods.csv')  # Replace with your actual data source
features = ['danceability', 'acousticness', 'energy', 'instrumentalness', 'liveness', 'valence', 'loudness', 'speechiness', 'tempo']
feature_matrix = data[features]


# Normalize the feature matrix
scaler = StandardScaler()
normalized_matrix = scaler.fit_transform(feature_matrix)

# Apply SVD
svd = TruncatedSVD(n_components=2)
decomposed_matrix = svd.fit_transform(normalized_matrix)
svd_matrix = np.dot(decomposed_matrix, svd.components_)

# Compute similarity matrix
similarity_matrix = cosine_similarity(svd_matrix)

import numpy as np
import random

import numpy as np
import pandas as pd
def recommend_songs(predicted_mood, num_recommendations=10):
    mood_recommendations = {
        'happy': ['happy', 'energetic'],
        'energetic': ['energetic', 'happy'],
        'neutral': ['happy', 'calm'],
        'calm': ['calm', 'happy'],
        'sad': ['calm', 'happy'],
        'angry': ['calm', 'energetic'],
        'fearful': ['calm', 'happy'],
        'disguised': ['calm', 'happy'],
        'surprised': ['calm', 'happy']
    }

    recommended_moods = mood_recommendations.get(predicted_mood.lower(), ['happy', 'calm'])
    recommended_songs = []

    if similarity_matrix.size == 0:
        print("Similarity matrix is empty.")
        return []

    for i, row in enumerate(similarity_matrix):
        if len(recommended_songs) >= num_recommendations:
            break
        
        similar_indices = np.argsort(row)[::-1]
        np.random.shuffle(similar_indices)

        for idx in similar_indices:
            song = data.iloc[idx]
            
            if song['mood'].lower() in recommended_moods:
                if song['name'] not in [r['name'] for r in recommended_songs]:
                    recommended_songs.append({
                        'name': song['name'],
                        'artist': song['artist']
                    })

                if len(recommended_songs) >= num_recommendations:
                    break

    if len(recommended_songs) < num_recommendations:
        additional_songs = []
        for mood in recommended_moods:
            for song in data.itertuples():
                if len(additional_songs) >= num_recommendations:
                    break
                if mood in song.mood.lower() and song.name not in [s['name'] for s in recommended_songs + additional_songs]:
                    additional_songs.append({
                        'name': song.name,
                        'artist': song.artist
                    })

        recommended_songs.extend(additional_songs[:num_recommendations - len(recommended_songs)])

    return recommended_songs


@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        if 'audio' not in request.files:
            return render_template("upload.html", message="No file part")

        myfile = request.files['audio']
        
        if myfile.filename == '':
            return render_template("upload.html", message="No selected file")

        accepted_formats = ['mp3', 'wav', 'ogg', 'flac']
        if not myfile.filename.split('.')[-1].lower() in accepted_formats:
            message = "Invalid file format. Accepted formats: {}".format(', '.join(accepted_formats))
            return render_template("upload.html", message=message)
        
        filename = myfile.filename
        mypath = os.path.join('static/audio/', filename)
        myfile.save(mypath)
        
        result = record_audio(record=False, file_loc=mypath)
        print(result)
        
        # Get recommendations based on the predicted mood
        mood = result
        recommendations = recommend_songs(predicted_mood=mood)
        print(recommendations)
        
        return render_template('upload.html', prediction=result, path=mypath, recommendations=recommendations)
    
    return render_template('upload.html')



CHUNK = 1024*4
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 48000

model=load_model("audio_model.h5")

#Extract features
def extract_features(file_name):
    X, sample_rate = librosa.load(file_name)
    #Short time fourier transformation
    stft = np.abs(librosa.stft(X))
    #Mel Frequency Cepstra coeff (40 vectors)
    mfccs=np.mean(librosa.feature.mfcc(y=X, sr=sample_rate, n_mfcc=40).T, axis=0)
    #Chromogram or power spectrum (12 vectors)
    chroma=np.mean(librosa.feature.chroma_stft(S=stft, sr=sample_rate).T, axis=0)
    #mel scaled spectogram (128 vectors)
    mel=np.mean(librosa.feature.melspectrogram(y=X, sr=sample_rate).T, axis=0)
    # Spectral contrast (7 vectors)
    contrast=np.mean(librosa.feature.spectral_contrast(S=stft, sr=sample_rate).T, axis=0)
    #tonal centroid features (6 vectors)
    tonnetz=np.mean(librosa.feature.tonnetz(y=librosa.effects.harmonic(X),sr=sample_rate).T, axis=0)
    return mfccs, chroma, mel, contrast, tonnetz

#generating predictions
def speech_to_emotion(filename):
    mfccs, chroma, mel, contrast, tonnetz= extract_features(filename)

    features=np.empty((0,193))
    f=np.hstack([mfccs, chroma, mel, contrast, tonnetz])
    features=np.vstack([features, f])

    his=model.predict(features)

    emotions=['neutral','calm','happy','sad','angry','fearful','disgused','surprised']
    y_pred=np.argmax(his, axis=1)
    pred_prob=np.max(his,axis=1)
    pred_emo=(emotions[y_pred[0]],pred_prob[0])
    print(1545651521,pred_emo)
    return pred_emo

def record_audio(record=True, file_loc=None):
    if record:
        p=pyaudio.PyAudio()
        stream=p.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, output=True, frames_per_buffer=CHUNK)

        # create matplotlib figure and axes
        fig, ax = plt.subplots(1, figsize=(7, 4))
        # variable for plotting
        x = np.arange(0, 2 * CHUNK, 2)
        # create a line object with random data
        line = ax.plot(x, np.random.rand(CHUNK), '-', lw=2)[0]
        # basic formatting for the axes
        ax.set_title('AUDIO WAVEFORM')
        ax.set_xlabel('Samples')
        ax.set_ylabel('Volume')
        ax.set_xlim(0, 2 * CHUNK)
        plt.setp(ax, xticks=[0, CHUNK, 2 * CHUNK], yticks=[-1000, 1000])
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        # show the plot
        plt.show(block=False)
        wm = plt.get_current_fig_manager()
        wm.window.attributes('-topmost', 1)
        #wm.window.attributes('-topmost', 0)

        frames = []
        for i in range(0, int(RATE / CHUNK * 5)):
            data = stream.read(CHUNK)
            frames.append(data)
            result = np.frombuffer(data, dtype=np.int16)
            line.set_ydata(result)
            fig.canvas.draw()
            fig.canvas.flush_events()
            prog=round((i*100)/(int(RATE/CHUNK*5)))
            plt.suptitle('Progress: '+str(prog)+"%")

        filename = "output.wav"

        # Save the recorded data as a WAV file
        wf = wave.open(filename, 'wb')
        wf.setnchannels(CHANNELS)
        wf.setsampwidth(p.get_sample_size(FORMAT))
        wf.setframerate(RATE)
        wf.writeframes(b''.join(frames))
        wf.close()

        main_dir = r'output.wav'
        pred = speech_to_emotion(main_dir)
        print(1111111,pred)
        #fig.suptitle(pred[0])
        fig.texts=[]
        plt.title('AUDIO WAVEFORM\nPredicted Emotion: '+str(pred[0].capitalize()))

        rec=wave.open(filename, 'r')
        return rec
    else:
        if file_loc:
            emo=speech_to_emotion(file_loc)[0]
            #print("The predicted emotion is: "+emo.capitalize())
            return emo.capitalize()


# @app.route('/audio', methods=['GET', 'POST'])
# def audio():
#     if request.method == 'POST':
#         myfile = request.files['file']
#         fn = myfile.filename
#         accepted_formats = ['mp3', 'wav', 'ogg', 'flac']
#         if fn.split('.')[-1].lower() not in accepted_formats:
#             message = "Invalid file format. Accepted formats: {}".format(', '.join(accepted_formats))
#             return render_template("audio.html", message = message)
#         mypath = os.path.join('static/audio/', fn)
#         myfile.save(mypath)

#         result = record_audio(record=False, file_loc=mypath) 
#         print(111111111111111111111111111, result)
#         return render_template('audio.html', prediction = result, path = mypath)
#     return render_template('audio.html')


if __name__ == '__main__':
    app.run(debug = True)